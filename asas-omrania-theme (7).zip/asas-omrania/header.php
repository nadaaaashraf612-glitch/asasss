<?php
/**
 * Header: <head>, skip link, site header (the original "site-header" component).
 */
if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<?php wp_head(); ?>
</head>
<body>
<?php
wp_body_open();
asas_ctx_push('global');
include ASAS_DIR . '/templates/global/skip.php';
include ASAS_DIR . '/templates/global/header.php';
asas_ctx_pop();

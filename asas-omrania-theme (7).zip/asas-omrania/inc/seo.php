<?php
/**
 * SEO integration.
 *
 * Meta titles / descriptions / XML sitemaps are managed by Rank Math SEO (edit them on each page / item).
 * The theme only adds what Rank Math cannot know about a two-URL (/ar/ + /en/) site:
 *   - hreflang alternates in <head>
 *   - a language-aware canonical
 *   - a sensible English fallback for title / description (optionally overridden per item with the
 *     "English SEO" box), and og:locale.
 * When Rank Math is not active, the theme prints a minimal title / description / canonical itself.
 */
if (!defined('ASAS_VERSION')) { exit; }

function asas_rank_math_active() {
    return defined('RANK_MATH_VERSION') || class_exists('RankMath');
}

function asas_brand() { return 'ASAS OMRANIA'; }

function asas_site_description($lang) {
    return $lang === 'ar'
        ? 'أساس العمرانية — استشارات هندسية وتصميم معماري وتخطيط وإدارة مشاريع.'
        : 'ASAS OMRANIA — engineering consultancy, architectural design, planning and project management.';
}

/** [ar, en] titles for the current object. */
function asas_object_titles() {
    $pages = [
        'home' => ['الرئيسية', 'Home'], 'about-us' => ['من نحن', 'About us'], 'services' => ['الخدمات', 'Services'],
        'projects' => ['المشاريع', 'Projects'], 'news' => ['الأخبار', 'Insights'], 'team' => ['فريقنا', 'Our team'],
        'clients' => ['عملاؤنا', 'Our clients'], 'contact' => ['تواصل معنا', 'Contact us'], 'careers' => ['الوظائف', 'Careers'],
        'privacy' => ['سياسة الخصوصية', 'Privacy policy'], 'terms' => ['الشروط والأحكام', 'Terms & conditions'],
    ];
    $o = get_queried_object();
    if (!($o instanceof WP_Post)) { return null; }
    if ($o->post_type === 'page') {
        $tpl = get_post_meta($o->ID, '_asas_tpl', true) ?: $o->post_name;
        return $pages[$tpl] ?? [$o->post_title, $o->post_title];
    }
    $f = asas_card_fields($o);
    return [$f['title']['ar'], $f['title']['en']];
}

function asas_seo_meta($key) {
    $o = get_queried_object();
    return ($o instanceof WP_Post) ? trim((string) get_post_meta($o->ID, $key, true)) : '';
}

/** Title used for English pages when Rank Math has no English text. */
function asas_en_title() {
    $custom = asas_seo_meta('_asas_seo_title_en');
    if ($custom !== '') { return $custom; }
    $t = asas_object_titles();
    return $t ? $t[1] . ' | ' . asas_brand() : get_bloginfo('name');
}
function asas_en_description() {
    $custom = asas_seo_meta('_asas_seo_desc_en');
    return $custom !== '' ? $custom : asas_site_description('en');
}

/* ---------------- hreflang + canonical ---------------- */
add_action('wp_head', function () {
    $route = asas_current_route();
    if ($route === null) { return; }
    foreach (ASAS_LANGS as $l) {
        printf('<link rel="alternate" hreflang="%s" href="%s">' . "\n", esc_attr($l), esc_url(asas_url($route, $l)));
    }
    printf('<link rel="alternate" hreflang="x-default" href="%s">' . "\n", esc_url(asas_url($route, ASAS_DEFAULT_LANG)));
    if (!asas_rank_math_active()) {
        printf('<link rel="canonical" href="%s">' . "\n", esc_url(asas_url($route)));
        $desc = asas_lang() === 'ar' ? asas_site_description('ar') : asas_en_description();
        printf('<meta name="description" content="%s">' . "\n", esc_attr($desc));
    }
}, 3);

/* ---------------- titles ---------------- */
add_filter('pre_get_document_title', function ($title) {
    if (asas_rank_math_active() || is_404()) { return $title; }
    $t = asas_object_titles();
    if (!$t) { return $title; }
    return (asas_lang() === 'ar' ? $t[0] : $t[1]) . ' | ' . asas_brand();
}, 20);

/* ---------------- Rank Math filters ---------------- */
add_filter('rank_math/frontend/canonical', function ($canonical) {
    $route = asas_current_route();
    return $route === null ? $canonical : asas_url($route);
});
add_filter('rank_math/frontend/title', function ($title) {
    if (asas_lang() === 'en' && is_singular()) {
        // Arabic (default) titles come from Rank Math; English ones from the optional box / fallback.
        return asas_en_title();
    }
    return $title;
});
add_filter('rank_math/frontend/description', function ($description) {
    if (asas_lang() === 'en' && is_singular()) { return asas_en_description(); }
    return $description;
});
add_filter('rank_math/opengraph/facebook/og_locale', function ($locale) {
    return asas_lang() === 'ar' ? 'ar_AR' : 'en_US';
});
add_filter('rank_math/opengraph/facebook/og_url', function ($url) {
    $route = asas_current_route();
    return $route === null ? $url : asas_url($route);
});
add_action('rank_math/head', function () {
    // alternate locale for Open Graph
    $other = asas_lang() === 'ar' ? 'en_US' : 'ar_AR';
    printf('<meta property="og:locale:alternate" content="%s">' . "\n", esc_attr($other));
});

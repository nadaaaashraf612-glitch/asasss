<?php
/**
 * Brochure helpers (route: /ar/brochure/{service}/ and /en/brochure/{service}/).
 */
if (!defined('ASAS_VERSION')) { exit; }

function asas_brochure_service() {
    $slug = sanitize_title(get_query_var('asas_brochure'));
    if (!$slug) { return null; }
    $p = get_posts(['name' => $slug, 'post_type' => 'asas_service', 'post_status' => 'publish', 'numberposts' => 1, 'suppress_filters' => true]);
    return $p ? $p[0] : null;
}

function asas_brochure_logo() {
    $f = ASAS_DIR . '/templates/brochure-logo.txt';
    return file_exists($f) ? trim(file_get_contents($f)) : asas_asset_url('assets/logo-dark-640.webp');
}

/** Card text of the service being rendered in a given language. */
function asas_card_text($name, $lang) {
    $c = asas_card_cur();
    if (!$c) { return ''; }
    $f = asas_card_fields($c['post']);
    return isset($f[$name][$lang]) ? $f[$name][$lang] : '';
}

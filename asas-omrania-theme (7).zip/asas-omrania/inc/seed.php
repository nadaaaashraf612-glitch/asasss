<?php
/**
 * Seeds the original site's pages and items (once per theme version), sets the home page as the
 * front page and enables pretty permalinks.
 */
if (!defined('ASAS_VERSION')) { exit; }

function asas_seed_pages() {
    return [
        'home' => 'الرئيسية', 'about-us' => 'من نحن', 'services' => 'الخدمات', 'projects' => 'المشاريع', 'news' => 'الأخبار',
        'team' => 'فريقنا', 'clients' => 'عملاؤنا', 'careers' => 'الوظائف', 'contact' => 'تواصل معنا',
        'privacy' => 'سياسة الخصوصية', 'terms' => 'الشروط والأحكام',
    ];
}

function asas_find_post($type, $slug) {
    $p = get_posts(['name' => $slug, 'post_type' => $type, 'post_status' => ['publish', 'draft', 'pending', 'private'], 'numberposts' => 1, 'suppress_filters' => true]);
    return $p ? $p[0] : null;
}

function asas_run_seed() {
    $seeds = asas_json('data/seeds.json');

    // Pretty permalinks are required for /ar/ and /en/.
    if (!get_option('permalink_structure')) {
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure('/%postname%/');
    }

    $front = 0;
    foreach (asas_seed_pages() as $slug => $title) {
        $p = asas_find_post('page', $slug);
        if (!$p) {
            $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => '']);
        } else { $id = $p->ID; }
        if ($id && !is_wp_error($id)) {
            update_post_meta($id, '_asas_tpl', $slug);
            if ($slug === 'home') { $front = $id; }
        }
    }
    if ($front) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $front);
    }

    $types = ['service' => 'asas_service', 'project' => 'asas_project', 'news' => 'asas_news'];
    foreach ($types as $key => $pt) {
        foreach ($seeds['order'][$key] as $i => $slug) {
            if (asas_find_post($pt, $slug)) { continue; }
            $title = $seeds[$key][$slug]['title']['ar'] ?? $slug;
            wp_insert_post(['post_type' => $pt, 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'menu_order' => $i + 1, 'post_content' => '']);
        }
    }
    update_option('asas_seed_version', ASAS_VERSION);
    update_option('blogname', get_option('blogname') ?: 'ASAS OMRANIA');
    flush_rewrite_rules(false);
}

add_action('after_switch_theme', 'asas_run_seed');
add_action('init', function () {
    if (get_option('asas_seed_version') !== ASAS_VERSION && did_action('init')) {
        asas_run_seed();
    }
}, 99);

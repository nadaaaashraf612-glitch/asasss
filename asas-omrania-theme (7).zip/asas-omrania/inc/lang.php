<?php
/**
 * Language routing: clean, separate URLs for each language (/ar/… and /en/…)
 * with identical English slugs. No JS show/hide of text.
 */
if (!defined('ASAS_VERSION')) { exit; }

const ASAS_LANGS = ['ar', 'en'];
const ASAS_DEFAULT_LANG = 'ar';

/** Post-type => URL base segment. */
function asas_cpt_bases() {
    return ['asas_service' => 'services', 'asas_project' => 'projects', 'asas_news' => 'news'];
}

/** Register rewrite rules (all prefixed by the language code). */
function asas_add_rewrite_rules() {
    add_rewrite_rule('^(ar|en)/?$', 'index.php?pagename=home&asas_lang=$matches[1]', 'top');
    foreach (asas_cpt_bases() as $pt => $base) {
        add_rewrite_rule('^(ar|en)/' . $base . '/([^/]+)/?$', 'index.php?post_type=' . $pt . '&name=$matches[2]&asas_lang=$matches[1]', 'top');
    }
    add_rewrite_rule('^(ar|en)/brochure/([^/]+)/?$', 'index.php?asas_brochure=$matches[2]&asas_lang=$matches[1]', 'top');
    add_rewrite_rule('^(ar|en)/([^/]+)/?$', 'index.php?pagename=$matches[2]&asas_lang=$matches[1]', 'top');
}
add_action('init', 'asas_add_rewrite_rules', 5);

add_filter('query_vars', function ($vars) {
    $vars[] = 'asas_lang';
    $vars[] = 'asas_brochure';
    return $vars;
});

/** Remember the language of the current request as early as possible. */
add_action('parse_request', function ($wp) {
    $GLOBALS['asas_request_lang'] = null;
    if (!empty($wp->query_vars['asas_lang']) && in_array($wp->query_vars['asas_lang'], ASAS_LANGS, true)) {
        $GLOBALS['asas_request_lang'] = $wp->query_vars['asas_lang'];
    }
});

/** True when the URL carries an explicit /ar/ or /en/ prefix. */
function asas_has_lang_in_request() {
    return !empty($GLOBALS['asas_request_lang']);
}

/** Current language ('ar' | 'en'). */
function asas_lang() {
    if (!empty($GLOBALS['asas_lang_override'])) {
        return $GLOBALS['asas_lang_override'];
    }
    if (!empty($GLOBALS['asas_request_lang'])) {
        return $GLOBALS['asas_request_lang'];
    }
    return ASAS_DEFAULT_LANG;
}

function asas_dir($lang = null) {
    return ($lang ?: asas_lang()) === 'ar' ? 'rtl' : 'ltr';
}

/** Build a clean URL for a route ('' = home, 'about-us', 'services/architecture' …). */
function asas_url($route = '', $lang = null) {
    $lang = $lang && in_array($lang, ASAS_LANGS, true) ? $lang : asas_lang();
    $route = trim((string) $route, '/');
    return home_url('/' . $lang . '/' . ($route !== '' ? $route . '/' : ''));
}

/** Route of a given post (page or CPT). */
function asas_post_route($post) {
    $post = get_post($post);
    if (!$post) { return ''; }
    if ($post->post_type === 'page') {
        $tpl = get_post_meta($post->ID, '_asas_tpl', true);
        if ($tpl === 'home' || (int) get_option('page_on_front') === (int) $post->ID) { return ''; }
        $uri = get_page_uri($post);
        return $uri;
    }
    $bases = asas_cpt_bases();
    if (isset($bases[$post->post_type])) {
        return $bases[$post->post_type] . '/' . $post->post_name;
    }
    return null;
}

/** Route of the page being displayed. */
function asas_current_route() {
    if (get_query_var('asas_brochure')) {
        return 'brochure/' . sanitize_title(get_query_var('asas_brochure'));
    }
    if (is_singular()) {
        $r = asas_post_route(get_queried_object());
        return $r === null ? '' : $r;
    }
    if (is_404()) { return null; }
    return '';
}

function asas_post_slug() {
    $o = get_queried_object();
    return ($o instanceof WP_Post) ? $o->post_name : '';
}

/** Permalinks always include the language prefix, so WordPress never "canonicalises" it away. */
add_filter('page_link', function ($link, $post_id) {
    $r = asas_post_route($post_id);
    return $r === null ? $link : asas_url($r);
}, 10, 2);
add_filter('post_type_link', function ($link, $post) {
    $r = asas_post_route($post);
    return $r === null ? $link : asas_url($r);
}, 10, 2);
add_filter('redirect_canonical', function ($redirect) {
    return asas_has_lang_in_request() ? false : $redirect;
});

/** URLs without a language prefix are sent (301) to the language version. */
add_action('template_redirect', function () {
    if (is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_preview() || is_customize_preview()) { return; }
    if (asas_has_lang_in_request()) {
        // Remember the last chosen language.
        if (!headers_sent() && (!isset($_COOKIE['asas_lang']) || $_COOKIE['asas_lang'] !== asas_lang())) {
            setcookie('asas_lang', asas_lang(), time() + YEAR_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), false);
        }
        return;
    }
    $lang = (isset($_COOKIE['asas_lang']) && in_array($_COOKIE['asas_lang'], ASAS_LANGS, true)) ? $_COOKIE['asas_lang'] : ASAS_DEFAULT_LANG;
    $target = null;
    if (is_front_page()) {
        $target = asas_url('', $lang);
    } elseif (is_singular()) {
        $r = asas_post_route(get_queried_object());
        if ($r !== null) { $target = asas_url($r, $lang); }
    }
    if ($target) {
        wp_safe_redirect($target, 301);
        exit;
    }
}, 1);

/** <html lang dir> */
add_filter('language_attributes', function ($output) {
    return 'lang="' . esc_attr(asas_lang()) . '" dir="' . esc_attr(asas_dir()) . '"';
});
add_filter('locale', function ($locale) {
    if (is_admin()) { return $locale; }
    return asas_lang() === 'ar' ? 'ar' : 'en_US';
});

/** Pick a string by language: asas_l('عربي', 'English'). */
function asas_l($ar, $en) {
    return asas_lang() === 'ar' ? $ar : $en;
}

/** Language switcher button in the header (keeps the original markup; the click navigates to the other URL). */
function asas_lang_button() {
    $ar = asas_lang() === 'ar';
    $other = $ar ? 'en' : 'ar';
    $route = asas_current_route();
    $url = asas_url($route === null ? '' : $route, $other);
    printf(
        '<button class="icon-button lang-button" data-lang data-href="%s" data-target-lang="%s" aria-label="%s" data-od-id="nav-language">%s</button>',
        esc_url($url),
        esc_attr($other),
        esc_attr($ar ? 'Switch to English' : 'التبديل إلى العربية'),
        $ar ? 'EN' : 'عربي'
    );
}

/** Active state of the main navigation, as in the original markup. */
function asas_nav_attrs($route) {
    $cur = asas_current_route();
    if ($cur === null) { return; }
    $section = explode('/', $cur)[0];
    if ($section === 'brochure') { $section = 'services'; }
    if ($section === $route) {
        echo ' class="active" aria-current="true"';
    }
}

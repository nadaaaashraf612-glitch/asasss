<?php
/**
 * Admin: native WordPress meta boxes + options page (no page builders).
 *  - "محتوى الصفحة" meta box on every converted page and on Services / Projects / News items
 *  - "بيانات البطاقة" meta box on Services / Projects / News (listing card fields, order via "Order")
 *  - "SEO بالإنجليزية" optional box (Arabic SEO is managed by Rank Math)
 *  - Top-level menu "إعدادات الموقع" for the header, footer, search and social dialogs
 * Images use the WordPress Media Uploader.
 */
if (!defined('ASAS_VERSION')) { exit; }

/* ------------------------------------------------------------------ helpers */
function asas_admin_post_info($post) {
    if ($post->post_type === 'page') {
        $tpl = get_post_meta($post->ID, '_asas_tpl', true) ?: $post->post_name;
        if (!file_exists(ASAS_DIR . '/data/sets/page-' . $tpl . '.json')) { return null; }
        return ['set' => 'page-' . $tpl, 'defaults' => [], 'type' => 'page'];
    }
    $map = ['asas_service' => 'service', 'asas_project' => 'project', 'asas_news' => 'news'];
    if (!isset($map[$post->post_type])) { return null; }
    $t = $map[$post->post_type];
    return ['set' => 'single-' . $t, 'defaults' => asas_post_defaults($t, $post->post_name), 'type' => $t];
}

function asas_snippet($s, $n = 70) {
    $s = trim(preg_replace('/\s+/', ' ', (string) $s));
    return function_exists('mb_strlen') && mb_strlen($s) > $n ? mb_substr($s, 0, $n) . '…' : $s;
}

/** Render all fields of a set, grouped into collapsible sections. */
function asas_render_fields($set_name, $ctx) {
    $set = asas_set($set_name);
    if (!$set['fields']) { echo '<p>—</p>'; return; }
    $groups = [];
    foreach ($set['fields'] as $f) { $groups[$f['group']][] = $f; }
    echo '<div class="asas-fields">';
    echo '<p class="asas-hint">كل حقل بلغتين: <b>العربية</b> (يمين) و<b>English</b> (يسار). اترك الحقل كما هو للاحتفاظ بالنص الأصلي. · Each field has Arabic (right) and English (left) inputs.</p>';
    $i = 0;
    foreach ($groups as $label => $fields) {
        echo '<details class="asas-group"' . ($i === 0 ? ' open' : '') . '><summary>' . esc_html($label) . ' <span class="asas-count">' . count($fields) . '</span></summary>';
        foreach ($fields as $f) {
            $k = $f['k'];
            $v = asas_field($k, $ctx);
            $name = 'asas_c[' . esc_attr($k) . ']';
            echo '<div class="asas-field asas-field--' . esc_attr($f['type']) . '">';
            if ($f['type'] === 'text') {
                echo '<label class="asas-label"><code>' . esc_html($f['tag'] ?? '') . '</code> ' . esc_html(asas_snippet($f['ar'])) . '</label><div class="asas-cols">';
                $long = strlen($v['ar']) > 70 || strlen($v['en']) > 70;
                foreach (['ar' => 'rtl', 'en' => 'ltr'] as $l => $dir) {
                    $rows = $long ? max(2, min(6, (int) ceil(strlen($v[$l]) / 70))) : 1;
                    echo '<textarea dir="' . $dir . '" rows="' . $rows . '" name="' . $name . '[' . $l . ']" placeholder="' . strtoupper($l) . '">' . esc_textarea($v[$l]) . '</textarea>';
                }
                echo '</div>';
            } elseif ($f['type'] === 'plain') {
                echo '<label class="asas-label"><code>' . esc_html($f['tag'] ?? '') . '</code> ' . esc_html(asas_snippet($f['v'])) . '</label>';
                echo '<input type="text" class="widefat" name="' . $name . '[v]" value="' . esc_attr($v['v']) . '">';
            } else {
                $preview = asas_image_src_from($v, 640);
                echo '<label class="asas-label"><code>img</code> ' . esc_html(asas_snippet($f['alt_ar'])) . '</label>';
                echo '<div class="asas-image">';
                echo '<img class="asas-image__preview" src="' . esc_url($preview) . '" alt="" data-default="' . esc_url(asas_asset_url($f['src'], 640)) . '">';
                echo '<div class="asas-image__tools"><input type="hidden" class="asas-image__id" name="' . $name . '[id]" value="' . (int) $v['id'] . '">';
                echo '<button type="button" class="button asas-pick">اختيار / تغيير الصورة · Choose image</button> ';
                echo '<button type="button" class="button-link asas-clear">الصورة الأصلية · Restore original</button>';
                echo '<div class="asas-cols"><input type="text" dir="rtl" name="' . $name . '[alt_ar]" value="' . esc_attr($v['alt_ar']) . '" placeholder="النص البديل (عربي)"><input type="text" dir="ltr" name="' . $name . '[alt_en]" value="' . esc_attr($v['alt_en']) . '" placeholder="Alt text (EN)"></div></div></div>';
            }
            echo '</div>';
        }
        echo '</details>';
        $i++;
    }
    echo '</div>';
}

/** Build the value array to store (only what differs from the defaults). */
function asas_collect_fields($set_name, $defaults, $posted) {
    $set = asas_set($set_name);
    $out = [];
    foreach ($set['fields'] as $f) {
        $k = $f['k'];
        if (!isset($posted[$k]) || !is_array($posted[$k])) { continue; }
        $p = wp_unslash($posted[$k]);
        $d = $defaults[$k] ?? [];
        if ($f['type'] === 'text') {
            foreach (['ar', 'en'] as $l) {
                if (!isset($p[$l])) { continue; }
                $val = trim(sanitize_textarea_field($p[$l]));
                $def = $d[$l] ?? $f[$l];
                if ($val !== '' && $val !== $def) { $out[$k][$l] = $val; }
            }
        } elseif ($f['type'] === 'plain') {
            $val = isset($p['v']) ? trim(sanitize_text_field($p['v'])) : '';
            $def = $d['v'] ?? $f['v'];
            if ($val !== '' && $val !== $def) { $out[$k]['v'] = $val; }
        } else {
            $id = isset($p['id']) ? absint($p['id']) : 0;
            if ($id) { $out[$k]['id'] = $id; }
            foreach (['alt_ar', 'alt_en'] as $a) {
                $val = isset($p[$a]) ? trim(sanitize_text_field($p[$a])) : '';
                $def = $d[$a] ?? $f[$a];
                if ($val !== '' && $val !== $def) { $out[$k][$a] = $val; }
            }
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ assets */
add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    $ours = in_array($hook, ['post.php', 'post-new.php'], true) || strpos($hook, 'asas-global') !== false || strpos($hook, 'asas_global') !== false;
    if (!$ours) { return; }
    wp_enqueue_media();
    wp_enqueue_style('asas-admin', ASAS_URI . '/assets/admin.css', [], ASAS_VERSION);
    wp_enqueue_script('asas-admin', ASAS_URI . '/assets/admin.js', ['jquery'], ASAS_VERSION, true);
});

/* ------------------------------------------------------------------ meta boxes */
add_action('add_meta_boxes', function ($post_type, $post) {
    $types = ['page', 'asas_service', 'asas_project', 'asas_news'];
    if (!in_array($post_type, $types, true) || !$post) { return; }
    $info = asas_admin_post_info($post);
    if ($info) {
        add_meta_box('asas_content', 'محتوى الصفحة — نصوص وصور (عربي / English)', function ($post) use ($info) {
            wp_nonce_field('asas_save', 'asas_nonce');
            echo '<label class="asas-reset"><input type="checkbox" name="asas_reset" value="1"> إعادة كل حقول هذه الصفحة إلى النص الأصلي · Reset all fields to the original content</label>';
            asas_render_fields($info['set'], ['set' => $info['set'], 'post' => $post->ID, 'defaults' => $info['defaults']]);
        }, $post_type, 'normal', 'high');
        add_meta_box('asas_seo_en', 'SEO بالإنجليزية (اختياري) · English SEO (optional)', function ($post) {
            echo '<p class="description">عناوين ووصف النسخة العربية تُدار بالكامل من Rank Math. هنا فقط عنوان ووصف النسخة الإنجليزية (/en/) إن أردت تخصيصهما. · Arabic SEO is managed by Rank Math; use these only for the /en/ version.</p>';
            printf('<p><label>SEO title (EN)<br><input type="text" class="widefat" dir="ltr" name="asas_seo_title_en" value="%s"></label></p>', esc_attr(get_post_meta($post->ID, '_asas_seo_title_en', true)));
            printf('<p><label>Meta description (EN)<br><textarea class="widefat" dir="ltr" rows="3" name="asas_seo_desc_en">%s</textarea></label></p>', esc_textarea(get_post_meta($post->ID, '_asas_seo_desc_en', true)));
        }, $post_type, 'side', 'default');
    }
    if ($post_type !== 'page') {
        add_meta_box('asas_card', 'بيانات البطاقة في القوائم (الرئيسية / الأقسام) · Listing card', 'asas_card_metabox', $post_type, 'normal', 'high');
    }
}, 10, 2);

function asas_card_metabox($post) {
    wp_nonce_field('asas_save', 'asas_nonce');
    $f = asas_card_fields($post);
    $t = ['asas_service' => 'service', 'asas_project' => 'project', 'asas_news' => 'news'][$post->post_type];
    echo '<p class="description">ترتيب العرض يتبع حقل «الترتيب» (Order) في صندوق Page Attributes. الرابط (Slug) إنجليزي ثابت للنسختين العربية والإنجليزية. · Display order follows the "Order" field; the English slug is shared by /ar/ and /en/.</p>';
    echo '<div class="asas-fields asas-card">';
    $bil = function ($label, $key, $long = false) use ($f) {
        echo '<div class="asas-field"><label class="asas-label">' . esc_html($label) . '</label><div class="asas-cols">';
        foreach (['ar' => 'rtl', 'en' => 'ltr'] as $l => $dir) {
            if ($long) { printf('<textarea dir="%s" rows="2" name="asas_card[%s][%s]">%s</textarea>', $dir, $key, $l, esc_textarea($f[$key][$l])); }
            else { printf('<input type="text" dir="%s" name="asas_card[%s][%s]" value="%s">', $dir, $key, $l, esc_attr($f[$key][$l])); }
        }
        echo '</div></div>';
    };
    $bil('العنوان · Title', 'title');
    if ($t !== 'service') { $bil($t === 'news' ? 'التصنيف · Category label' : 'التخصص · Category label', 'category'); }
    if ($t !== 'news') { $bil('وصف مختصر · Short description', 'desc', true); } 
    if ($t === 'service') { /* desc shown above */ }
    if ($t === 'project') {
        echo '<div class="asas-field"><label class="asas-label">فلتر التصنيف · Filter group</label><select name="asas_card[cat_key]">';
        foreach (['architecture' => 'عمارة · Architecture', 'planning' => 'تخطيط عمراني · Urban planning', 'interior' => 'تصميم داخلي · Interiors'] as $k => $l) { printf('<option value="%s"%s>%s</option>', $k, selected($f['cat_key'], $k, false), esc_html($l)); }
        echo '</select></div>';
        printf('<div class="asas-field"><label class="asas-label">القطاع · Sector (سكن / عام / أعمال)</label><input type="text" name="asas_card[sector]" value="%s"></div>', esc_attr($f['sector']));
        printf('<div class="asas-field"><label class="asas-label">السنة · Year</label><input type="text" name="asas_card[year]" value="%s" size="6"></div>', esc_attr($f['year']));
    }
    if ($t === 'news') {
        echo '<div class="asas-field"><label class="asas-label">فلتر التصنيف · Filter group</label><select name="asas_card[cat_key]">';
        foreach (['design' => 'تصميم · Design', 'engineering' => 'هندسة · Engineering', 'urban' => 'عمران · Urbanism'] as $k => $l) { printf('<option value="%s"%s>%s</option>', $k, selected($f['cat_key'], $k, false), esc_html($l)); }
        echo '</select></div>';
        printf('<div class="asas-field"><label class="asas-label">تاريخ النشر · Publication date</label><input type="date" name="asas_card[date]" value="%s"></div>', esc_attr($f['date']));
    }
    // image
    $def = asas_card_defaults($post);
    $v = ['src' => $f['image']['src'], 'id' => $f['image']['id']];
    echo '<div class="asas-field"><label class="asas-label">صورة البطاقة والغلاف · Card & hero image</label><div class="asas-image">';
    echo '<img class="asas-image__preview" src="' . esc_url(asas_image_src_from($v, 640)) . '" alt="" data-default="' . esc_url(asas_asset_url($def['image'] ?? 'assets/architecture-hero-960.webp', 640)) . '">';
    echo '<div class="asas-image__tools"><input type="hidden" class="asas-image__id" name="asas_card[image_id]" value="' . (int) $f['image']['id'] . '">';
    echo '<button type="button" class="button asas-pick">اختيار / تغيير الصورة · Choose image</button> <button type="button" class="button-link asas-clear">الصورة الأصلية · Restore original</button></div></div></div>';
    // related
    if ($t === 'service' || $t === 'news') {
        $pt = $t === 'service' ? 'asas_project' : 'asas_news';
        $posts = get_posts(['post_type' => $pt, 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'post_status' => 'publish', 'exclude' => [$post->ID]]);
        echo '<div class="asas-field"><label class="asas-label">' . ($t === 'service' ? 'مشاريع ذات صلة · Related projects' : 'مقالات ذات صلة (أول 3) · Related articles (first 3)') . '</label><div class="asas-checks">';
        foreach ($posts as $p) {
            $ff = asas_card_fields($p);
            printf('<label><input type="checkbox" name="asas_card[related][]" value="%s"%s> %s</label>', esc_attr($p->post_name), checked(in_array($p->post_name, $f['related'], true), true, false), esc_html($ff['title']['ar'] . ' · ' . $ff['title']['en']));
        }
        echo '</div><input type="hidden" name="asas_card[related_present]" value="1"></div>';
    }
    echo '</div>';
}

add_action('save_post', function ($post_id, $post) {
    if (!isset($_POST['asas_nonce']) || !wp_verify_nonce($_POST['asas_nonce'], 'asas_save')) { return; }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (!current_user_can('edit_post', $post_id)) { return; }
    $info = asas_admin_post_info($post);

    if ($info && isset($_POST['asas_c'])) {
        if (!empty($_POST['asas_reset'])) { delete_post_meta($post_id, '_asas_content'); }
        else {
            $store = asas_collect_fields($info['set'], $info['defaults'], (array) $_POST['asas_c']);
            if ($store) { update_post_meta($post_id, '_asas_content', $store); } else { delete_post_meta($post_id, '_asas_content'); }
        }
    }
    if ($info && $post->post_type !== 'page' && isset($_POST['asas_card'])) {
        $c = wp_unslash((array) $_POST['asas_card']);
        $d = asas_card_defaults($post);
        $s = [];
        foreach (['title', 'desc', 'category'] as $k) {
            foreach (['ar', 'en'] as $l) {
                if (isset($c[$k][$l])) {
                    $val = trim(sanitize_textarea_field($c[$k][$l]));
                    if ($val !== '' && $val !== ($d[$k][$l] ?? '')) { $s[$k][$l] = $val; }
                }
            }
        }
        foreach (['cat_key', 'sector', 'year', 'date'] as $k) {
            if (isset($c[$k])) { $val = trim(sanitize_text_field($c[$k])); if ($val !== '' && $val !== ($d[$k] ?? '')) { $s[$k] = $val; } }
        }
        if (!empty($c['image_id'])) { $s['image_id'] = absint($c['image_id']); }
        if (!empty($c['related_present'])) {
            $rel = isset($c['related']) ? array_map('sanitize_title', (array) $c['related']) : [];
            if ($rel !== ($d['related'] ?? [])) { $s['related'] = $rel; }
        }
        if ($s) { update_post_meta($post_id, '_asas_card', $s); } else { delete_post_meta($post_id, '_asas_card'); }
    }
    if (isset($_POST['asas_seo_title_en'])) { update_post_meta($post_id, '_asas_seo_title_en', sanitize_text_field(wp_unslash($_POST['asas_seo_title_en']))); }
    if (isset($_POST['asas_seo_desc_en'])) { update_post_meta($post_id, '_asas_seo_desc_en', sanitize_textarea_field(wp_unslash($_POST['asas_seo_desc_en']))); }
}, 10, 2);

/* ------------------------------------------------------------------ global settings page */
add_action('admin_menu', function () {
    add_menu_page('إعدادات الموقع', 'إعدادات الموقع · ASAS', 'edit_theme_options', 'asas-global', 'asas_global_page', 'dashicons-admin-appearance', 20);
});

function asas_global_page() {
    if (!current_user_can('edit_theme_options')) { return; }
    if (isset($_POST['asas_global_nonce']) && wp_verify_nonce($_POST['asas_global_nonce'], 'asas_global_save')) {
        if (!empty($_POST['asas_reset'])) { delete_option('asas_global'); }
        else {
            $store = asas_collect_fields('global', [], isset($_POST['asas_c']) ? (array) $_POST['asas_c'] : []);
            update_option('asas_global', $store, false);
        }
        echo '<div class="notice notice-success is-dismissible"><p>تم حفظ الإعدادات · Settings saved.</p></div>';
    }
    echo '<div class="wrap asas-wrap"><h1>إعدادات الموقع — الهيدر والفوتر والبحث · Site settings</h1>';
    echo '<p>نصوص وصور الهيدر (الشعار وروابط القائمة) والفوتر (الوصف، بيانات التواصل، الروابط القانونية) ونافذة البحث ونافذة حسابات التواصل. تظهر في كل صفحات الموقع. · Header, footer, search and social dialog content shown on every page.</p>';
    echo '<form method="post">';
    wp_nonce_field('asas_global_save', 'asas_global_nonce');
    echo '<label class="asas-reset"><input type="checkbox" name="asas_reset" value="1"> إعادة الكل إلى النص الأصلي · Reset to original</label>';
    asas_render_fields('global', ['set' => 'global', 'post' => 0, 'defaults' => []]);
    submit_button('حفظ · Save');
    echo '</form></div>';
}

/* Helpful admin columns */
add_filter('manage_pages_columns', function ($c) { $c['asas_route'] = 'روابط AR / EN'; return $c; });
add_action('manage_pages_custom_column', function ($col, $id) {
    if ($col !== 'asas_route') { return; }
    $r = asas_post_route($id);
    if ($r === null) { return; }
    printf('<a href="%1$s" target="_blank">/ar/%3$s</a> · <a href="%2$s" target="_blank">/en/%3$s</a>', esc_url(asas_url($r, 'ar')), esc_url(asas_url($r, 'en')), esc_html($r));
}, 10, 2);

<?php
/**
 * Theme setup: assets, head, title tag, clean-ups.
 */
if (!defined('ASAS_VERSION')) { exit; }

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
    add_theme_support('automatic-feed-links');
});

/* Front-end assets: the original CSS / JS, byte for byte. */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('asas-tokens', ASAS_URI . '/assets/design-tokens.css', [], ASAS_VERSION);
    wp_enqueue_style('asas-site', ASAS_URI . '/assets/site.css', ['asas-tokens'], ASAS_VERSION);
    wp_enqueue_script('asas-site', ASAS_URI . '/assets/site.js', [], ASAS_VERSION, ['strategy' => 'defer', 'in_footer' => false]);
    wp_enqueue_script('asas-wp', ASAS_URI . '/assets/asas-wp.js', ['asas-site'], ASAS_VERSION, ['strategy' => 'defer', 'in_footer' => false]);

    // Runs before site.js: the page language is decided by the URL, so tell the original script about it.
    $lang = asas_lang();
    wp_add_inline_script('asas-site', 'try{localStorage.setItem("asas-lang",' . wp_json_encode($lang) . ');}catch(e){}window.__asasTitle=document.title;', 'before');

    $routes = [];
    wp_add_inline_script('asas-wp', 'window.asasWP=' . wp_json_encode([
        'lang' => $lang,
        'home' => asas_url(''),
        'base' => untrailingslashit(home_url('/' . $lang)),
    ]) . ';', 'before');
}, 20);

/* Remove WordPress front-end extras that would interfere with the original design. */
add_action('wp_enqueue_scripts', function () {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('classic-theme-styles');
    wp_dequeue_style('global-styles');
}, 100);
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rel_canonical'); // canonical is handled in inc/seo.php (language aware)

/* Head markup identical to the original document head (fonts, viewport, theme colour). */
add_action('wp_head', function () {
    ?>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0D0446">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Changa:wght@400;500;600;700&amp;display=swap" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Changa:wght@400;500;600;700&amp;display=swap" media="all"></noscript>
    <?php
}, 2);

/* Search dialog + social dialog + footer are printed by footer.php. */
add_filter('body_class', function ($classes) { return []; });
add_filter('show_admin_bar', function ($show) { return $show; });

/* Templates for custom query vars. */
add_filter('template_include', function ($template) {
    if (get_query_var('asas_brochure')) {
        $t = ASAS_DIR . '/brochure.php';
        if (file_exists($t)) { return $t; }
    }
    return $template;
}, 99);

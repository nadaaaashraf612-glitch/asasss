<?php
/**
 * Custom post types: Services, Projects, News. URLs are produced by inc/lang.php (rewrite => false here).
 */
if (!defined('ASAS_VERSION')) { exit; }

add_action('init', function () {
    $defs = [
        'asas_service' => ['الخدمات', 'خدمة', 'Services', 'dashicons-hammer'],
        'asas_project' => ['المشاريع', 'مشروع', 'Projects', 'dashicons-building'],
        'asas_news'    => ['الأخبار', 'خبر / مقال', 'News', 'dashicons-megaphone'],
    ];
    $pos = 21;
    foreach ($defs as $type => $d) {
        register_post_type($type, [
            'labels' => [
                'name' => $d[0] . ' · ' . $d[2],
                'singular_name' => $d[1],
                'menu_name' => $d[0] . ' · ' . $d[2],
                'add_new' => 'إضافة جديد',
                'add_new_item' => 'إضافة ' . $d[1],
                'edit_item' => 'تعديل ' . $d[1],
                'view_item' => 'عرض',
                'all_items' => 'كل ' . $d[0],
                'search_items' => 'بحث',
                'not_found' => 'لا يوجد محتوى',
            ],
            'public' => true,
            'publicly_queryable' => true,
            'show_in_rest' => false,
            'has_archive' => false,
            'rewrite' => false,
            'query_var' => true,
            'menu_icon' => $d[3],
            'menu_position' => $pos++,
            'supports' => ['title', 'page-attributes', 'thumbnail'],
        ]);
    }
    // Pages are edited through the content meta boxes, not the block editor.
    remove_post_type_support('page', 'editor');
}, 9);

<?php
/**
 * Content engine: every text / image of the original front-end is a field with a built-in default
 * (extracted from the original HTML) that can be overridden from the WordPress admin.
 *
 *  - Pages      : post meta  _asas_content   (edited in the "محتوى الصفحة" meta box)
 *  - Services / Projects / News (CPT): same + card fields in _asas_card
 *  - Header/Footer/Search (global)   : option asas_global (Appearance ▸ "إعدادات الموقع")
 */
if (!defined('ASAS_VERSION')) { exit; }

/* ------------------------------------------------------------------ data loading */
function asas_json($relative) {
    static $cache = [];
    if (!isset($cache[$relative])) {
        $file = ASAS_DIR . '/' . $relative;
        $cache[$relative] = file_exists($file) ? json_decode(file_get_contents($file), true) : null;
    }
    return $cache[$relative];
}

/** Field schema of a set ("global", "page-home", "single-service" …): list + map by key. */
function asas_set($name) {
    static $cache = [];
    if (!isset($cache[$name])) {
        $d = asas_json('data/sets/' . $name . '.json');
        $fields = $d ? $d['fields'] : [];
        $map = [];
        foreach ($fields as $f) { $map[$f['k']] = $f; }
        $cache[$name] = ['fields' => $fields, 'map' => $map];
    }
    return $cache[$name];
}

/** Defaults specific to a post (e.g. the "villa" project), falling back to the set defaults. */
function asas_post_defaults($type, $slug) {
    $d = asas_json('data/defaults/' . $type . '-' . $slug . '.json');
    return is_array($d) ? $d : [];
}

/* ------------------------------------------------------------------ context */
/**
 * The context says where the field values live.
 * ['set' => 'page-home', 'post' => 12, 'defaults' => [...]]  or  ['set' => 'global']
 */
function asas_ctx_push($set, $post_id = 0, $defaults = []) {
    $GLOBALS['asas_ctx_stack'][] = ['set' => $set, 'post' => (int) $post_id, 'defaults' => $defaults];
}
function asas_ctx_pop() { array_pop($GLOBALS['asas_ctx_stack']); }
function asas_ctx() {
    $s = $GLOBALS['asas_ctx_stack'] ?? [];
    return $s ? end($s) : ['set' => 'global', 'post' => 0, 'defaults' => []];
}

function asas_stored($ctx) {
    static $cache = [];
    $id = $ctx['post'];
    $ck = $ctx['set'] . ':' . $id;
    if (!isset($cache[$ck])) {
        $v = $ctx['set'] === 'global' ? get_option('asas_global', []) : get_post_meta($id, '_asas_content', true);
        $cache[$ck] = is_array($v) ? $v : [];
    }
    return $cache[$ck];
}

/** Effective raw value (stored overrides default) of one field. */
function asas_field($key, $ctx = null) {
    $ctx = $ctx ?: asas_ctx();
    $set = asas_set($ctx['set']);
    if (!isset($set['map'][$key])) { return null; }
    $f = $set['map'][$key];
    $stored = asas_stored($ctx);
    $def = $ctx['defaults'][$key] ?? null;
    $out = [];
    if ($f['type'] === 'text') {
        $out = ['ar' => $def['ar'] ?? $f['ar'], 'en' => $def['en'] ?? $f['en']];
        foreach (['ar', 'en'] as $l) {
            if (isset($stored[$key][$l]) && $stored[$key][$l] !== '') { $out[$l] = $stored[$key][$l]; }
        }
    } elseif ($f['type'] === 'plain') {
        $out = ['v' => $def['v'] ?? $f['v']];
        if (isset($stored[$key]['v']) && $stored[$key]['v'] !== '') { $out['v'] = $stored[$key]['v']; }
    } else { // img
        $out = ['src' => $def['src'] ?? $f['src'], 'id' => 0, 'alt_ar' => $def['alt_ar'] ?? $f['alt_ar'], 'alt_en' => $def['alt_en'] ?? $f['alt_en']];
        if (!empty($stored[$key]['id'])) { $out['id'] = (int) $stored[$key]['id']; }
        foreach (['alt_ar', 'alt_en'] as $a) {
            if (isset($stored[$key][$a]) && $stored[$key][$a] !== '') { $out[$a] = $stored[$key][$a]; }
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ template tags */
/** Localised text (escaped). */
function asas_t($key, $lang = null) {
    $v = asas_field($key);
    if (!$v) { return ''; }
    $lang = $lang ?: asas_lang();
    return esc_html($v[$lang] ?? '');
}
/** Raw localised text for use in PHP logic. */
function asas_tr($key, $lang = null) {
    $v = asas_field($key);
    return $v ? ($v[$lang ?: asas_lang()] ?? '') : '';
}
/** Language-neutral text (numbers, e-mail, phone …). */
function asas_p($key) {
    $v = asas_field($key);
    return $v ? esc_html($v['v']) : '';
}

/** Resolve a theme asset (e.g. assets/foo-960.webp) to a width variant. */
function asas_asset_url($path, $w = null) {
    $path = preg_replace('#^(\.\./)+#', '', ltrim($path, '/'));
    if (strpos($path, 'assets/') !== 0) { $path = 'assets/' . $path; }
    if ($w) { $path = preg_replace('/-\d+(\.\w+)$/', '-' . (int) $w . '$1', $path); }
    return ASAS_URI . '/' . $path;
}
function asas_image_src_from($v, $w = null) {
    if (!empty($v['id'])) {
        $u = wp_get_attachment_image_url($v['id'], 'full');
        if ($u) { return $u; }
    }
    $src = $v['src'] ?? '';
    if (preg_match('#^https?://#', $src)) { return $src; }
    return asas_asset_url($src, $w);
}
function asas_image_srcset_from($v, $widths) {
    if (!empty($v['id'])) {
        $s = wp_get_attachment_image_srcset($v['id'], 'full');
        return $s ?: '';
    }
    $src = $v['src'] ?? '';
    if (preg_match('#^https?://#', $src) || !preg_match('/-\d+\.\w+$/', $src)) { return ''; }
    $parts = [];
    foreach ($widths as $w) { $parts[] = asas_asset_url($src, $w) . ' ' . (int) $w . 'w'; }
    return implode(', ', $parts);
}
function asas_src($key) {
    $v = asas_field($key);
    if (!$v) { return ''; }
    // keep the original resolution used by the markup (e.g. -960)
    $orig = asas_set(asas_ctx()['set'])['map'][$key]['src'] ?? '';
    $w = preg_match('/-(\d+)\.\w+$/', $v['src'] ?? $orig, $m) ? (int) $m[1] : null;
    return asas_image_src_from($v, $w);
}
function asas_srcset($key, $widths) {
    $v = asas_field($key);
    return $v ? asas_image_srcset_from($v, $widths) : '';
}
function asas_alt($key) {
    $v = asas_field($key);
    return $v ? esc_attr($v['alt_' . asas_lang()] ?? '') : '';
}

/* ------------------------------------------------------------------ cards (CPT items shown as cards) */
function asas_card_defaults($post) {
    $type = ['asas_service' => 'service', 'asas_project' => 'project', 'asas_news' => 'news'][$post->post_type] ?? null;
    $seeds = asas_json('data/seeds.json');
    return $type && isset($seeds[$type][$post->post_name]) ? $seeds[$type][$post->post_name] : [];
}

/** Effective card fields of a service / project / article post. */
function asas_card_fields($post) {
    static $cache = [];
    $post = get_post($post);
    if (isset($cache[$post->ID])) { return $cache[$post->ID]; }
    $d = asas_card_defaults($post);
    $s = get_post_meta($post->ID, '_asas_card', true);
    $s = is_array($s) ? $s : [];
    $f = [];
    foreach (['title', 'desc', 'category'] as $k) {
        $f[$k] = ['ar' => $d[$k]['ar'] ?? '', 'en' => $d[$k]['en'] ?? ''];
        foreach (['ar', 'en'] as $l) { if (isset($s[$k][$l]) && $s[$k][$l] !== '') { $f[$k][$l] = $s[$k][$l]; } }
    }
    if ($f['title']['ar'] === '') { $f['title']['ar'] = $post->post_title; }
    if ($f['title']['en'] === '') { $f['title']['en'] = $post->post_title; }
    foreach (['cat_key', 'sector', 'year', 'date'] as $k) {
        $f[$k] = isset($s[$k]) && $s[$k] !== '' ? $s[$k] : ($d[$k] ?? '');
    }
    $f['image'] = ['src' => $d['image'] ?? 'assets/architecture-hero-960.webp', 'id' => !empty($s['image_id']) ? (int) $s['image_id'] : 0];
    $f['related'] = isset($s['related']) && is_array($s['related']) ? $s['related'] : ($d['related'] ?? []);
    return $cache[$post->ID] = $f;
}

function asas_format_date_en($iso) {
    $t = strtotime($iso . ' 12:00:00 UTC');
    return $t ? gmdate('j F Y', $t) : '';
}

/** Posts for a card list. $args: limit, exclude_current, related. */
function asas_cards($post_type, $args = []) {
    $limit = $args['limit'] ?? -1;
    $current = $GLOBALS['asas_card_stack'][0]['post'] ?? null;
    $base = ['post_type' => $post_type, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => ['menu_order' => 'ASC', 'ID' => 'ASC'], 'no_found_rows' => true, 'suppress_filters' => true];
    if (!empty($args['related']) && $current) {
        $slugs = asas_card_fields($current)['related'];
        $out = [];
        foreach ($slugs as $slug) {
            $p = get_posts(['name' => $slug, 'post_type' => $post_type, 'post_status' => 'publish', 'numberposts' => 1, 'suppress_filters' => true]);
            if ($p) { $out[] = $p[0]; }
        }
        return $limit > 0 ? array_slice($out, 0, $limit) : $out;
    }
    $posts = get_posts($base);
    if (!empty($args['exclude_current']) && $current) {
        $posts = array_values(array_filter($posts, function ($p) use ($current) { return $p->ID !== $current->ID; }));
    }
    return $limit > 0 ? array_slice($posts, 0, $limit) : $posts;
}

function asas_card_begin($post, $i = 0) {
    $GLOBALS['asas_card_stack'][] = ['post' => $post, 'i' => $i];
    // the stack's first item is the queried single; keep index 0 stable
}
function asas_card_end() { array_pop($GLOBALS['asas_card_stack']); }
function asas_card_cur() {
    $s = $GLOBALS['asas_card_stack'] ?? [];
    return $s ? end($s) : null;
}

function asas_cf_raw($name) {
    $c = asas_card_cur();
    if (!$c) { return ''; }
    $f = asas_card_fields($c['post']);
    switch ($name) {
        case 'num': return sprintf('%02d', $c['i'] + 1);
        case 'date_label': return $f['date'] ? asas_format_date_en($f['date']) : 'Publication date not specified';
        case 'search': return trim($f['title']['ar'] . ' ' . $f['title']['en'] . ' ' . $f['category']['ar'] . ' ' . $f['category']['en']);
        case 'date': return $f['date'];
        case 'cat_key': case 'sector': case 'year': return $f[$name];
    }
    if (isset($f[$name]) && is_array($f[$name]) && isset($f[$name]['ar'])) { return $f[$name][asas_lang()]; }
    return '';
}
function asas_cf($name) { return esc_html(asas_cf_raw($name)); }
function asas_card_url() {
    $c = asas_card_cur();
    return $c ? asas_url(asas_post_route($c['post'])) : '#';
}
function asas_card_image() {
    $c = asas_card_cur();
    return $c ? asas_card_fields($c['post'])['image'] : ['src' => '', 'id' => 0];
}
function asas_card_src($w = 960) { return asas_image_src_from(asas_card_image(), $w); }
function asas_card_srcset($widths) { return asas_image_srcset_from(asas_card_image(), $widths); }

/* ------------------------------------------------------------------ rendering helpers */
/** Output a converted page / single template with the proper content context. */
function asas_render_template($file, $set, $post, $defaults = []) {
    $path = ASAS_DIR . '/templates/' . $file . '.php';
    if (!file_exists($path)) { return false; }
    asas_ctx_push($set, $post ? $post->ID : 0, $defaults);
    include $path;
    asas_ctx_pop();
    return true;
}

function asas_render_current() {
    $post = get_queried_object();
    $GLOBALS['asas_card_stack'] = [];
    if ($post instanceof WP_Post) {
        if ($post->post_type === 'page') {
            $tpl = get_post_meta($post->ID, '_asas_tpl', true) ?: $post->post_name;
            if (asas_render_template('pages/' . $tpl, 'page-' . $tpl, $post)) { return; }
        } else {
            $map = ['asas_service' => 'service', 'asas_project' => 'project', 'asas_news' => 'news'];
            if (isset($map[$post->post_type])) {
                $t = $map[$post->post_type];
                $GLOBALS['asas_card_stack'] = [['post' => $post, 'i' => 0]];
                asas_render_template('single/' . $t, 'single-' . $t, $post, asas_post_defaults($t, $post->post_name));
                return;
            }
        }
        // Unknown page: print the editor content inside the site's standard container
        echo '<main id="main-content"><section class="section"><div class="container copy">';
        echo apply_filters('the_content', $post->post_content);
        echo '</div></section></main>';
    }
}

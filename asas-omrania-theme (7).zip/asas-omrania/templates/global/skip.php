<a class="skip-link" href="#main-content"><span><?= asas_t('t1') ?></span></a>

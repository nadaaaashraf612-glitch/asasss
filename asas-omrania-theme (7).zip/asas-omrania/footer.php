<?php
/**
 * Footer: the original "site-footer" component + search dialog + social dialog.
 */
if (!defined('ABSPATH')) { exit; }
asas_ctx_push('global');
include ASAS_DIR . '/templates/global/footer.php';
include ASAS_DIR . '/templates/global/search.php';
include ASAS_DIR . '/templates/global/info.php';
asas_ctx_pop();
wp_footer();
?>
</body>
</html>

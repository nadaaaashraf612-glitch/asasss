<?php
/**
 * Fallback template (404 and anything not handled by a dedicated template).
 */
if (!defined('ABSPATH')) { exit; }
get_header();
if (is_singular()) {
    asas_render_current();
} else {
    status_header(404);
    ?>
<main id="main-content">
  <section class="company-hero">
    <div class="container company-hero__grid">
      <div class="company-hero__copy">
        <p class="eyebrow"><?php echo esc_html(asas_l('أساس العمرانية', 'ASAS OMRANIA')); ?></p>
        <h1>404</h1>
        <p class="copy"><?php echo esc_html(asas_l('الصفحة المطلوبة غير موجودة.', 'The page you requested could not be found.')); ?></p>
        <a class="button button--accent" href="<?php echo esc_url(asas_url('')); ?>"><span><?php echo esc_html(asas_l('العودة إلى الرئيسية', 'Back to home')); ?></span></a>
      </div>
    </div>
  </section>
</main>
    <?php
}
get_footer();

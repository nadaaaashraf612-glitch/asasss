<?php
/**
 * Renders the converted original template for the current page / item.
 */
if (!defined('ABSPATH')) { exit; }
get_header();
asas_render_current();
get_footer();

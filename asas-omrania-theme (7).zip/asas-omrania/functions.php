<?php
/**
 * ASAS OMRANIA theme bootstrap.
 */
if (!defined('ABSPATH')) { exit; }

define('ASAS_VERSION', '1.0.0');
define('ASAS_DIR', get_template_directory());
define('ASAS_URI', get_template_directory_uri());

require_once ASAS_DIR . '/inc/lang.php';
require_once ASAS_DIR . '/inc/content.php';
require_once ASAS_DIR . '/inc/cpt.php';
require_once ASAS_DIR . '/inc/setup.php';
require_once ASAS_DIR . '/inc/seo.php';
require_once ASAS_DIR . '/inc/seed.php';
require_once ASAS_DIR . '/inc/brochure.php';
if (is_admin()) {
    require_once ASAS_DIR . '/inc/admin.php';
}

/* ASAS OMRANIA — admin helpers: WordPress Media Uploader for image fields */
(function ($) {
  'use strict';
  $(document).on('click', '.asas-pick', function (e) {
    e.preventDefault();
    var box = $(this).closest('.asas-image');
    var frame = wp.media({ title: 'اختر صورة · Choose image', button: { text: 'استخدم الصورة · Use image' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      box.find('.asas-image__id').val(a.id);
      var url = (a.sizes && a.sizes.medium_large ? a.sizes.medium_large.url : a.url);
      box.find('.asas-image__preview').attr('src', url);
    });
    frame.open();
  });
  $(document).on('click', '.asas-clear', function (e) {
    e.preventDefault();
    var box = $(this).closest('.asas-image');
    box.find('.asas-image__id').val('');
    var img = box.find('.asas-image__preview');
    img.attr('src', img.data('default'));
  });
})(jQuery);

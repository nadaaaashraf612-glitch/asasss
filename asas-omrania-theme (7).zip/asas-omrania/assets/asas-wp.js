/* ASAS OMRANIA — WordPress companion for the original site.js (which is kept unmodified).
 * - the language is decided by the URL (/ar/ or /en/), so the language button navigates to the other URL
 * - keeps the server-rendered <title> and image alt texts (Rank Math / editor values)
 * - maps the original static-file links used by the built-in search index to the theme's clean URLs
 */
(function () {
  'use strict';
  var cfg = window.asasWP || {};
  var lang = cfg.lang === 'en' ? 'en' : 'ar';

  /* 1. Language button: navigate instead of toggling text in place. Capture phase runs before site.js. */
  document.addEventListener('click', function (event) {
    var button = event.target.closest && event.target.closest('[data-lang]');
    if (!button) { return; }
    var url = button.getAttribute('data-href');
    if (!url) { return; }
    event.preventDefault();
    event.stopImmediatePropagation();
    try { document.cookie = 'asas_lang=' + button.getAttribute('data-target-lang') + ';path=/;max-age=31536000;samesite=lax'; } catch (e) {}
    window.location.assign(url);
  }, true);

  /* 2. Restore server-rendered title and image alt values that site.js rewrites on load. */
  function restore() {
    if (window.__asasTitle) { document.title = window.__asasTitle; }
    document.querySelectorAll('img[data-alt-ar]').forEach(function (img) {
      var alt = img.getAttribute('data-alt-ar');
      if (alt !== null && img.getAttribute('alt') !== alt) { img.setAttribute('alt', alt); }
    });
  }
  restore();

  /* 3. Search results created by site.js link to the original .html files → clean theme URLs. */
  var PAGES = {
    'asas-omrania-website.html': '', 'asas-omrania-1.html': '', 'about-us.html': 'about-us/', 'services.html': 'services/',
    'projects.html': 'projects/', 'news.html': 'news/', 'team.html': 'team/', 'clients.html': 'clients/',
    'careers.html': 'careers/', 'contact.html': 'contact/', 'privacy.html': 'privacy/', 'terms.html': 'terms/'
  };
  function mapHref(href) {
    if (!href || /^(https?:|mailto:|tel:|#|javascript:)/.test(href)) { return null; }
    var parts = href.split('#'), frag = parts[1] ? '#' + parts[1] : '';
    var pq = parts[0].split('?'), file = pq[0].split('/').pop(), qs = new URLSearchParams(pq[1] || ''), m, route = null;
    if (Object.prototype.hasOwnProperty.call(PAGES, file)) { route = PAGES[file]; }
    else if ((m = file.match(/^service-(\w+)\.html$/))) { route = 'services/' + (m[1] === 'details' ? 'architecture' : m[1]) + '/'; }
    else if (file === 'project-details.html') { route = 'projects/' + (qs.get('project') || 'villa') + '/'; }
    else if (file === 'news-details.html') { route = 'news/' + (qs.get('article') || 'facade') + '/'; }
    else if ((m = file.match(/^brochure-(\w+)\.html$/))) { route = 'brochure/' + m[1] + '/'; }
    if (route === null) { return null; }
    return (cfg.base || '') + '/' + route + frag;
  }
  function fixLinks(root) {
    root.querySelectorAll('a[href]').forEach(function (a) {
      var next = mapHref(a.getAttribute('href'));
      if (next) { a.setAttribute('href', next); }
    });
  }
  var results = document.querySelector('.search-results');
  if (results && 'MutationObserver' in window) {
    new MutationObserver(function () { fixLinks(results); }).observe(results, { childList: true, subtree: true });
    fixLinks(results);
  }
})();
